package net.minecraft.server;

import net.minecraft.server.ISource;

public interface ILocationSource extends ISource {
}
