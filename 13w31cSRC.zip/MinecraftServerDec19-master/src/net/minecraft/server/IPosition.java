package net.minecraft.server;

public interface IPosition {
   double getX();

   double getY();

   double getZ();
}
