package net.minecraft.server;

public interface INamable {
   String getName();
}
