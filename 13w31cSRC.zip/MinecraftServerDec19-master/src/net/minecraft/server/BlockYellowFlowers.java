package net.minecraft.server;


public class BlockYellowFlowers extends BlockFlowers {

	@Override
	public BlockFlowers.EnumFlowerType getFlowerType() {
		return BlockFlowers.EnumFlowerType.YELLOW;
	}

}
