package net.minecraft.server;

public enum EnumProtocolDirection {
	SERVERBOUND, CLIENTBOUND;
}
