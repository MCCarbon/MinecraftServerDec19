package net.minecraft.server;

import net.minecraft.server.class_amb;

public class BlockWoodStep extends class_amb {
   public boolean isDouble() {
      return false;
   }
}
