package net.minecraft.server;

import net.minecraft.server.Item;

public class ItemNetherStar extends Item {
}
