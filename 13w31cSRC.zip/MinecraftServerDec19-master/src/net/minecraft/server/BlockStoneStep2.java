package net.minecraft.server;

import net.minecraft.server.class_ajp;

public class BlockStoneStep2 extends class_ajp {
   public boolean isDouble() {
      return false;
   }
}
