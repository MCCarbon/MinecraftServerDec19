package net.minecraft.server;

import net.minecraft.server.class_agp;

public class BlockWoodButton extends class_agp {
   protected BlockWoodButton() {
      super(true);
   }
}
