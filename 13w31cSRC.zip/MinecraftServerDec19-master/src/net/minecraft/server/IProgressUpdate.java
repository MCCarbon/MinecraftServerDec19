package net.minecraft.server;

public interface IProgressUpdate {
   void a(String var1);

   void c(String var1);

   void a(int var1);
}
