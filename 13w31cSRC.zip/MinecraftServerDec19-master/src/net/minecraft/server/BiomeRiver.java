package net.minecraft.server;

import net.minecraft.server.BiomeBase;

public class BiomeRiver extends BiomeBase {
   public BiomeRiver(int var1) {
      super(var1);
      this.au.clear();
   }
}
