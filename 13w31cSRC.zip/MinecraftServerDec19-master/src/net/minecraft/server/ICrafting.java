package net.minecraft.server;

import java.util.List;
import net.minecraft.server.ItemStack;
import net.minecraft.server.IInventory;
import net.minecraft.server.Container;

public interface ICrafting {
   void a(Container var1, List var2);

   void a(Container var1, int var2, ItemStack var3);

   void a(Container var1, int var2, int var3);

   void a(Container var1, IInventory var2);
}
