package net.minecraft.server;

import net.minecraft.server.InventorySubContainer;

public interface IInventoryListener {
   void a(InventorySubContainer var1);
}
