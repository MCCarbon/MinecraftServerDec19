package net.minecraft.server;

import net.minecraft.server.class_ajp;

public class BlockDoubleStoneStep2 extends class_ajp {
   public boolean isDouble() {
      return true;
   }
}
