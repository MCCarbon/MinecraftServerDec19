package net.minecraft.server;

import net.minecraft.server.class_agp;

public class BlockStoneButton extends class_agp {
   protected BlockStoneButton() {
      super(false);
   }
}
