package net.minecraft.server;

import net.minecraft.server.InventorySubContainer;

public class InventoryHorseChest extends InventorySubContainer {
   public InventoryHorseChest(String var1, int var2) {
      super(var1, false, var2);
   }
}
