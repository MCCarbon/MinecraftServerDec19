package net.minecraft.server;

public interface IProjectile {
   void shoot(double var1, double var3, double var5, float var7, float var8);
}
