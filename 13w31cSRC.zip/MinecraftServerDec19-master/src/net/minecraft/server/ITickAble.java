package net.minecraft.server;

public interface ITickAble {

	void tick();

}
