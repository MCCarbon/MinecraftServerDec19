package net.minecraft.server;

public enum EnumAnimation {
	NONE, EAT, DRINK, BLOCK, BOW;
}
