package net.minecraft.server;

import net.minecraft.server.BlockDoubleStepAbstract;

public class BlockStep extends BlockDoubleStepAbstract {
   public boolean isDouble() {
      return false;
   }
}
