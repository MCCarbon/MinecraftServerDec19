package net.minecraft.server;

public enum EnumUsedHand {
   MAIN_HAND,
   OFF_HAND;
}
