package net.minecraft.server;


public class BlockRedFlowers extends BlockFlowers {

	@Override
	public BlockFlowers.EnumFlowerType getFlowerType() {
		return BlockFlowers.EnumFlowerType.RED;
	}

}
