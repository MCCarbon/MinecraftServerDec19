package net.minecraft.server;

import net.minecraft.server.BlockDoubleStepAbstract;

public class BlockDoubleStep extends BlockDoubleStepAbstract {

	public boolean isDouble() {
		return true;
	}

}
